AUDI is a package for multi-label active learning. This package includes the MATLAB implementation of AUDI, which queries instance-label pairs based on both uncertainty and diversity.

Please start with AUDI.m. AUDI returns the selected instance-label pairs.

This package was developed by Dr. Sheng-Jun Huang (huangsj@lamda.nju.edu.cn).